#ifndef HEADSORTAILS_H
#define HEADSORTAILS_H

#include "globals.h"
#include "../coinfliplogic.h"
#include "../timer.h"

#include <vector>

class GamePlay;
class Player;
class ViewInterface;

enum BaseResult {
	LOSE, WIN, BIGWIN
};

class Game 
{
public:
    virtual void play() =0;

    virtual void doubleResult() = 0;
};

/**
 * This class is responsible for implementing the 
 * game logic.
 */ 
class HeadsOrTailsGame : public Game
{
public:
    HeadsOrTailsGame(ICoinFlipLogic* cfl, ViewInterface* view);
    virtual ~HeadsOrTailsGame();

public: // from game
    void play();
    void doubleResult();

    void showNextCoin();
    BaseResult getBaseResult();
    bool getDoubleResult();
    bool canContinueToDouble();
    
private: // data members
    void randomtana();
    int countSides(Side side);
    bool canContinueAfterTwoCoins();

    ICoinFlipLogic* mCfl;
    std::vector<Side> mBaseResults;
    ViewInterface* mView;
    bool mTwoFirstAreTails;
    bool mCanContinueToDouble;
};

#endif //HEADSORTAILS_H
