#include "headsortailsgame.h"
#include "../viewinterface.h"
#include <time.h>
#include <stdlib.h>
#include <iostream>
#include "../timer.h"

#include "../coinfliplogic.h"

HeadsOrTailsGame::HeadsOrTailsGame(ICoinFlipLogic* cfl, ViewInterface* view) : mBaseResults()
{
	mCfl = cfl;
	mView = view;
	mCanContinueToDouble = false;
}

HeadsOrTailsGame::~HeadsOrTailsGame()
{
}

void HeadsOrTailsGame::showNextCoin()
{
	static int i = 0;
	mView->showBaseGameCoin(i, mBaseResults[i]);
	i++;
	if (i > 2)
		i = 0;
}

void HeadsOrTailsGame::play()
{
    mView->resetGraphics();
	mCanContinueToDouble = false;

	long unsigned int delay = 500;
	int delayFactor = 0;
	randomtana();
	std::tr1::function <void()> func;
	func = std::tr1::bind( &HeadsOrTailsGame::showNextCoin, this);
//	Timer::getInstance()->delay(func, delay*delayFactor++);
//	Timer::getInstance()->delay(func, delay*delayFactor++);

	mView->showBaseGameCoin(0, mBaseResults[0]);
	mView->showBaseGameCoin(1, mBaseResults[1]);
	if (canContinueAfterTwoCoins())
		mView->showBaseGameCoin(2, mBaseResults[2]);
	//	Timer::getInstance()->delay(func, delay*delayFactor++);

	switch (getBaseResult())
	{
	case LOSE:
		mView->showGameLoss();
		break;
	case BIGWIN:
		mView->showBigWin();
		break;
	case WIN:
		mView->showDoubleUpScreen();
		mCanContinueToDouble = true;
		break;
	}
}

void HeadsOrTailsGame::doubleResult()
{
	if ( canContinueToDouble() )
	{
		mView->resetDoubleUpScreenGraphics();
		Side result = mCfl->flip();
		mView->showDoubleUpCoin(result);
		mView->showDoubleupResult( (result == Heads) );
		mCanContinueToDouble = (result == Heads);
		if (mCanContinueToDouble)
			mView->showDoubleUpScreen();
	}
}


void HeadsOrTailsGame::randomtana() {

	mTwoFirstAreTails = true;
	mBaseResults.clear();
	for (int i = 0; i < 3; i++)
	{
		Side result = mCfl->flip();
		if (mTwoFirstAreTails == true && result == Heads && i < 2)
			mTwoFirstAreTails = false;
		mBaseResults.push_back(result);
	}
}

BaseResult HeadsOrTailsGame::getBaseResult() {

	if (countSides(Heads) == 2)
		return WIN;

	if (countSides(Heads) == 3)
		return BIGWIN;

	return LOSE;
}

int HeadsOrTailsGame::countSides(Side side)
{
	int rv = 0;
	for (std::vector<Side>::iterator it = mBaseResults.begin(); it != mBaseResults.end(); it++)
		if (*it == side)
			rv++;
	return rv;
}

bool HeadsOrTailsGame::canContinueAfterTwoCoins()
{
	return !mTwoFirstAreTails;
}

bool HeadsOrTailsGame::canContinueToDouble()
{
	return mCanContinueToDouble;
}

