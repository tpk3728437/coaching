#ifndef GLOBALS_H
#define GLOBALS_H

enum Side {
    Tails = 0,
    Heads
};

#endif // GLOBALS_H
