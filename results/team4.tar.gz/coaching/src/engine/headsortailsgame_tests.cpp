#include <limits.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "headsortailsgame.h"
#include "../coinfliplogic.h"
#include "../viewinterface.h"

#include <vector>

using ::testing::_;
using ::testing::Return;
using ::testing::InSequence;
using ::testing::AllOf;
using ::testing::Ge;
using ::testing::Le;
using ::testing::Invoke;



class ViewMock : public ViewInterface
{
public:
    virtual ~ViewMock() {}
    virtual void startRendering(){};
    virtual void quit() {};
    virtual void setInputInspector(InputInspector& inputInspector) {};
    virtual void resetGraphics() {};
//    virtual void showDoubleUpScreen() {};
//    virtual void resetDoubleUpScreenGraphics() {};
//    virtual void showDoubleupResult(bool win) {};
//    virtual void showGameLoss() {};
//    virtual void showBigWin() {};
    //virtual void showBaseGameCoin(int index, Side side) {};
    virtual void showDoubleUpCoin(Side side) {};
    virtual ViewportSize getViewportSize() const {};
    virtual std::string windowHandle() const {};

    MOCK_METHOD0(resetDoubleUpScreenGraphics, void());
    MOCK_METHOD0(showGameLoss, void());
    MOCK_METHOD0(showBigWin, void());
    MOCK_METHOD2(showBaseGameCoin, void(int, Side));
    MOCK_METHOD0(showDoubleUpScreen, void());
    MOCK_METHOD1(showDoubleupResult, void(bool));
};

class CoinFlipMock : public ICoinFlipLogic {
public:
	CoinFlipMock() : mResult(), idx(-1) {}

	virtual ~CoinFlipMock() {}

	void setSides(Side side1, Side side2, Side side3) {
		idx = 0;
		mResult.clear();
		mResult.push_back(side1);
		mResult.push_back(side2);
		mResult.push_back(side3);
	}

	virtual Side flip()
	{
		if (idx >- 1 && idx < 3)
			return mResult[idx++];
		assert(false && "Too many flips");
		return Heads;
	}

private:
	std::vector<Side> mResult;
	int idx;
};

class HeadsOrTailsGameTest : public ::testing::Test
{
public:
	HeadsOrTailsGameTest() : ::testing::Test() {
		cf = new CoinFlipMock();
		view = new ViewMock();
		mHT = new HeadsOrTailsGame(cf, view);
		EXPECT_CALL(*view, showBaseGameCoin(0, _)).Times(::testing::Exactly(1));
		EXPECT_CALL(*view, showBaseGameCoin(1, _)).Times(::testing::Exactly(1));
		EXPECT_CALL(*view, showBaseGameCoin(2, _)).Times(::testing::Exactly(1));
	}

	virtual ~HeadsOrTailsGameTest() {
		delete mHT;
		delete cf;
		delete view;
	}


	HeadsOrTailsGame* mHT;
	CoinFlipMock* cf;
	ViewMock* view;
};


class HeadsOrTailsGameTestPlain : public ::testing::Test
{
public:
	HeadsOrTailsGameTestPlain() : ::testing::Test() {
		cf = new CoinFlipMock();
		view = new ViewMock();
		mHT = new HeadsOrTailsGame(cf, view);
	}

	virtual ~HeadsOrTailsGameTestPlain() {
		delete mHT;
		delete cf;
		delete view;
	}

	HeadsOrTailsGame* mHT;
	CoinFlipMock* cf;
	ViewMock* view;
};


TEST_F(HeadsOrTailsGameTest, lose_with_two_tails)
{    
	EXPECT_CALL(*view, showGameLoss()).Times(::testing::Exactly(1));
	cf->setSides(Tails, Heads, Tails);
	mHT->play();
	ASSERT_EQ(LOSE, mHT->getBaseResult());
}

TEST_F(HeadsOrTailsGameTest, win_basic_win)
{
	EXPECT_CALL(*view, showDoubleUpScreen()).Times(::testing::Exactly(1));
	cf->setSides(Heads, Tails, Heads);
	mHT->play();
	ASSERT_EQ(WIN, mHT->getBaseResult());
}


TEST_F(HeadsOrTailsGameTest, win_BIG_win)
{
	EXPECT_CALL(*view, showBigWin()).Times(::testing::Exactly(1));
	cf->setSides(Heads, Heads, Heads);
	mHT->play();
	ASSERT_EQ(BIGWIN, mHT->getBaseResult());
}

TEST_F(HeadsOrTailsGameTestPlain, view_no_third_coin_in_case_of_two_tails)
{
	EXPECT_CALL(*view, showBaseGameCoin(0, Tails)).Times(::testing::Exactly(1));
	EXPECT_CALL(*view, showBaseGameCoin(1, Tails)).Times(::testing::Exactly(1));
	EXPECT_CALL(*view, showBaseGameCoin(2, Tails)).Times(::testing::Exactly(0));
	EXPECT_CALL(*view, showGameLoss()).Times(::testing::Exactly(1));
	cf->setSides(Tails, Tails, Heads);
	mHT->play();
}

TEST_F(HeadsOrTailsGameTest, can_double_after_win)
{
	EXPECT_CALL(*view, showDoubleUpScreen()).Times(::testing::Exactly(1));
	cf->setSides(Heads, Heads, Tails);
	mHT->play();
	ASSERT_EQ(true, mHT->canContinueToDouble());
}

TEST_F(HeadsOrTailsGameTest, double_win_after_win)
{
	EXPECT_CALL(*view, showDoubleUpScreen()).Times(::testing::Exactly(2));
	EXPECT_CALL(*view, showDoubleupResult(true)).Times(::testing::Exactly(1));
	EXPECT_CALL(*view, resetDoubleUpScreenGraphics()).Times(::testing::Exactly(1));
	cf->setSides(Heads, Tails, Heads);
	mHT->play();
	cf->setSides(Heads, Tails, Heads);
	mHT->doubleResult();
}

TEST_F(HeadsOrTailsGameTest, double_win_after_double_win)
{
	EXPECT_CALL(*view, showDoubleUpScreen()).Times(::testing::Exactly(3));
	EXPECT_CALL(*view, showDoubleupResult(true)).Times(::testing::Exactly(2));
	EXPECT_CALL(*view, resetDoubleUpScreenGraphics()).Times(::testing::Exactly(2));
	cf->setSides(Heads, Tails, Heads);
	mHT->play();
	cf->setSides(Heads, Tails, Heads);
	mHT->doubleResult();
	cf->setSides(Heads, Tails, Heads);
	mHT->doubleResult();
}

TEST_F(HeadsOrTailsGameTest, _double_lose_after_win)
{
	EXPECT_CALL(*view, showDoubleUpScreen()).Times(::testing::Exactly(1));
	EXPECT_CALL(*view, showDoubleupResult(false)).Times(::testing::Exactly(1));
	EXPECT_CALL(*view, resetDoubleUpScreenGraphics()).Times(::testing::Exactly(1));

	cf->setSides(Heads, Tails, Heads);
	mHT->play();
	cf->setSides(Tails, Tails, Heads);
	mHT->doubleResult();
}

TEST_F(HeadsOrTailsGameTest, no_double_after_BIG_win)
{
	EXPECT_CALL(*view, showDoubleUpScreen()).Times(::testing::Exactly(0));
	EXPECT_CALL(*view, showDoubleupResult(false)).Times(::testing::Exactly(0));
	EXPECT_CALL(*view, showBigWin()).Times(::testing::Exactly(1));

	cf->setSides(Heads, Heads, Heads);
	mHT->play();
	ASSERT_EQ(false, mHT->canContinueToDouble());
	cf->setSides(Tails, Tails, Heads);
	mHT->doubleResult();
}
