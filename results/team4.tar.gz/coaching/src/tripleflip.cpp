#include "tripleflip.h"
#include "view.h"
#include "headsortailsgame.h"
#include "coinfliplogic.h"


TripleFlipApp::TripleFlipApp()
{
    mView = new View();
    mController = new AppController(*mView);
    mCoinFlipLogic = new CoinFlipLogic();
    mGameEngine = new HeadsOrTailsGame(mCoinFlipLogic, mView);
    mController->setEngine(*mGameEngine);
}
  
TripleFlipApp::~TripleFlipApp()
{
    delete mGameEngine;
    delete mView;
    delete mCoinFlipLogic;
    delete mController;
}
  
void TripleFlipApp::start()
{
    mView->startRendering();
}
