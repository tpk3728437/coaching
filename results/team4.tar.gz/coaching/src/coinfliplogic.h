#ifndef COINFLIPLOGIC_H
#define COINFLIPLOGIC_H

#include "engine/globals.h"

class ICoinFlipLogic {
public:
	virtual ~ICoinFlipLogic() {};
	virtual Side flip()=0;
};

/**
 * This class is responsible for implementing the coin flipping
 * algorithm. Each call to the flip function will flip the coin
 * and return the result.
 */
class CoinFlipLogic :public ICoinFlipLogic
{
public:
    CoinFlipLogic();
    virtual ~CoinFlipLogic();

    virtual Side flip();
    
private:

};

#endif // COINFLIPLOGIC_H

