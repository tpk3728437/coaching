#ifndef UITYPES_H
#define UITYPES_H

#include <utility>

typedef std::pair<int,int> ViewportSize;

#endif // UITYPES_H
