#include "headsortailsgame.h"
#include <time.h>
#include <stdlib.h>

HeadsOrTailsGame::HeadsOrTailsGame(CoinFlipLogic& logic) :
		mCoinFlipLogic(logic) {
}

HeadsOrTailsGame::~HeadsOrTailsGame() {
}

void HeadsOrTailsGame::play() {
	mFlips.clear();

	mFlips.push_back(mCoinFlipLogic.flip());
	mFlips.push_back(mCoinFlipLogic.flip());

	if (checkResult() != LOSE_TWO_COINS)
		mFlips.push_back(mCoinFlipLogic.flip());
}

void HeadsOrTailsGame::playDoubling() {
	mFlips.clear();
	mFlips.push_back(mCoinFlipLogic.flip());
}
GameResult HeadsOrTailsGame::checkResult() {
	int tailsCount = 0;
	int headsCount = 0;
	for (int i = 0; i < mFlips.size(); ++i) {
		if (mFlips[i] == Tails)
			tailsCount++;
		if (mFlips[i] == Heads)
			headsCount++;

		if (tailsCount == 2) {
			if (i == 1)
				return LOSE_TWO_COINS;
			else return LOSE_THREE_COINS;
		}

	}

	if (headsCount == 3)
		return WINBIG;
	else if (headsCount == 2)
		return WIN;
	return LOSE_THREE_COINS;

}

GameResult HeadsOrTailsGame::checkDoublingResult() {
	if (mFlips.size() == 0)
		return DOUBLING_LOSE;

	return mFlips[0] == Heads ? DOUBLING_WIN : DOUBLING_LOSE;
}
