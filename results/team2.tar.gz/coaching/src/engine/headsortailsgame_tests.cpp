#include <limits.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "headsortailsgame.h"

#include "../coinfliplogic.h"

using ::testing::_;
using ::testing::Return;
using ::testing::InSequence;
using ::testing::AllOf;
using ::testing::Ge;
using ::testing::Le;
using ::testing::Invoke;



class StubCoinFlipLogicCustom : public CoinFlipLogic
{
public:
	StubCoinFlipLogicCustom(Side s1,Side s2, Side s3) :index(0)  {
	 sides[0] = s1;
	 sides[1] = s2;
	 sides[2] = s3;
	}
	Side flip() {
		return sides[index++];
	}
private:
	int index;
	Side sides[3];
};




class HeadsOrTailsGameTest : public ::testing::Test
{
public:
//	HeadsOrTailsGameTest() {game.play()};
//	HeadsOrTailsGame game;
public:
};

TEST_F(HeadsOrTailsGameTest, lose_with_two_tails)
{    
	StubCoinFlipLogicCustom logic(Tails,Tails,Heads);

	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(LOSE_TWO_COINS,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest, win_with_two_heads)
{
	StubCoinFlipLogicCustom logic(Tails,Heads,Heads);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(WIN,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest, loses_with_three_coins)
{
	StubCoinFlipLogicCustom logic(Tails,Heads,Tails);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(LOSE_THREE_COINS,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest, jackpot)
{
	StubCoinFlipLogicCustom logic(Heads,Heads,Heads);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(WINBIG,game.checkResult());

}

TEST_F(HeadsOrTailsGameTest, skip_third_coin_with_two_tails) {
	StubCoinFlipLogicCustom logic(Tails,Tails,Heads);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(LOSE_TWO_COINS,game.checkResult());
	ASSERT_EQ(2, game.getCoinsFlipped());

}


