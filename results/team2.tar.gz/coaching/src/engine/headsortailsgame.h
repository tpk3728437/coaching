#ifndef HEADSORTAILS_H
#define HEADSORTAILS_H


#include "../coinfliplogic.h"


#include "globals.h"
#include <vector>

class GamePlay;
class Player;

enum GameResult {
	WIN,
	LOSE_TWO_COINS,
	LOSE_THREE_COINS,
	WINBIG,
	DOUBLING_WIN,
	DOUBLING_LOSE
};

class Game 
{
public:
    virtual void play() =0;
    virtual void playDoubling() =0;
    virtual Side getSide(int index) = 0;
    virtual GameResult checkResult() = 0;
    virtual GameResult checkDoublingResult() = 0;
    virtual int getCoinsFlipped() = 0;
};

/**
 * This class is responsible for implementing the 
 * game logic.
 */ 
class HeadsOrTailsGame : public Game
{
public:
    HeadsOrTailsGame(CoinFlipLogic& logic);
    virtual ~HeadsOrTailsGame();

public: // from game
    void play();
    void playDoubling();
    
    GameResult checkResult();
    GameResult checkDoublingResult();

    Side getSide(int index) {
    	return mFlips[index];
    }

    int getCoinsFlipped() {
    	return (int)mFlips.size();
    }

private: // data members
    CoinFlipLogic&           mCoinFlipLogic;
    std::vector<Side> mFlips;

};



#endif //HEADSORTAILS_H
