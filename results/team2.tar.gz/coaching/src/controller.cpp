#include "controller.h"
#include "headsortailsgame.h"
#include <memory>
#include "view.h"
#include <iostream>


Controller::Controller(ViewInterface& view) : mView(view), mGameEngine(0), mCurrentState(READY)
{
}

Controller::~Controller()
{
}

void Controller::setEngine(Game& gameEngine)
{
    std::cout << "setEngine: " << (unsigned long)&gameEngine << std::endl;

    mGameEngine = &gameEngine;
}

void Controller::quitButtonPressed()
{
    mView.quit();
}

void Controller::playButtonPressed()
{
    std::cout << "Play button pressed" << std::endl;


    switch(mCurrentState) {

    case WIN_AND_DOUBLE_QUERY:
    case READY:
    {

    	mCurrentState = BASEGAME;

        mView.resetGraphics();

        if (mGameEngine) {
            mGameEngine->play();
        }

        std::cout << "mGameEngine: " << (unsigned long)mGameEngine << std::endl;

        GameResult result = mGameEngine->checkResult();
        int coinCount = 0;

        std::cout << "CheckResult" << std::endl;

		switch (result) {
			case WIN:
				mCurrentState = WIN_AND_DOUBLE_QUERY;
				mView.showDoubleUpScreen();
				coinCount = 3;
				break;

			case LOSE_THREE_COINS:
				mCurrentState = READY;
				coinCount = 3;
				mView.showGameLoss();

				break;
			case LOSE_TWO_COINS:
				mCurrentState = READY;
				mView.showGameLoss();
				coinCount = 2;
				break;

			case WINBIG:
				mCurrentState = READY;
				coinCount = 3;
				mView.showBigWin();
				break;
			default:
				break;
		}

		for (int i = 0; i < coinCount; ++i) {
			mView.showBaseGameCoin(i, mGameEngine->getSide(i));
		}
    }
        break;


    default:
    	break;
    }






}

void Controller::doubleUpButtonPressed()
{
    std::cout << "tuplausnappia painettu" << std::endl;
    mView.resetDoubleUpScreenGraphics();

    switch (mCurrentState) {
		case WIN_AND_DOUBLE_QUERY:
			mCurrentState = DOUBLE;
			mGameEngine->playDoubling();

			if (mGameEngine->checkDoublingResult() == DOUBLING_WIN) {
				mCurrentState = WIN_AND_DOUBLE_QUERY;
				mView.showDoubleupResult(true);
			}
			else {
				mCurrentState = READY;
				mView.showDoubleupResult(false);
			}

			mView.showDoubleUpCoin( mGameEngine->getSide(0) );

			break;
		default:
			break;
	}

    // TODO: Käyttäjä on painanut tuplausnappia, siirry tuplaustilaan

}

void Controller::payoutButtonPressed()
{
    std::cout << "voittojen lunastusnappia painettu" << std::endl;

    // TODO: käyttäjä on painanut voittojen lunastus nappia
    // siirry tuplaustilasta pois


    switch (mCurrentState) {
		case WIN_AND_DOUBLE_QUERY:
			mCurrentState = READY;

			break;
		default:
			break;
	}

	mView.resetGraphics();

}
