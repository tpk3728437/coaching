#include "tripleflip.h"

int main()
{
    TripleFlipApp* app = new TripleFlipApp();
    app->start();
    delete app;
    
    return 0;
}
