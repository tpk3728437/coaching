#ifndef MOCK_GAME_H
#define MOCK_GAME_H

#include <gmock/gmock.h>
#include "headsortailsgame.h"


class MockGame : public Game
{
public:
    MOCK_METHOD0(play, void());
    MOCK_METHOD1(getSide, Side(int));
//    MOCK_METHOD0(checkResult, GameResult());
    MOCK_METHOD0(getCoinsFlipped, int());
    MOCK_METHOD0(checkDoublingResult, GameResult());
    MOCK_METHOD0(playDoubling, void());

    GameResult checkResult() {
    	return WIN;
    }

};

#endif // MOCK_GAME_H
