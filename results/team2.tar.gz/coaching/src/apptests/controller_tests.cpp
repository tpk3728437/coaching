#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "controller.h"
#include "viewinterface.h"
#include "headsortailsgame.h"
#include "inputhandler.h"
#include "mock_game.h"
#include "mock_view.h"
#include "coinfliplogic.h"

using ::testing::_;
using ::testing::Return;


class ButtonDriver
{
public:
    ButtonDriver(UserCommandObserver& userCommandObserver) : mUserCommandObserver(userCommandObserver) {}
    void pressQuitButton() { mUserCommandObserver.quitButtonPressed(); }
    void pressPlayButton() { mUserCommandObserver.playButtonPressed(); }
    void pressDoubleUpButton() { mUserCommandObserver.doubleUpButtonPressed(); }
    void pressPayoutButton() { mUserCommandObserver.payoutButtonPressed(); }

private:
    UserCommandObserver& mUserCommandObserver;
};



class AlwaysWinGame : public HeadsOrTailsGame {
public:

	AlwaysWinGame(CoinFlipLogic& logic) : HeadsOrTailsGame(logic) {}

    GameResult checkResult() {
    	return WIN;
    }

};


class ControllerTest : public ::testing::Test
{
public:
    ControllerTest() {}
    ~ControllerTest() {}
    MockView& view() { return mockView; }
private:
    MockView mockView;
    ViewportSize size;
};

TEST_F(ControllerTest, initialization)
{        
    Controller controller(view());
}

TEST_F(ControllerTest, quit_button_press_quits_view_rendering)
{
    Controller controller(view());
    EXPECT_CALL(view(), quit());
    ButtonDriver driver(controller);
    driver.pressQuitButton();
}

TEST_F(ControllerTest, play_button_press_resets_graphics_and_start_new_game)
{
    Controller controller(view());
    EXPECT_CALL(view(), resetGraphics()).Times(1);
    ButtonDriver driver(controller);

    MockGame mockGame;
    EXPECT_CALL(mockGame, play());

    ON_CALL(mockGame, getSide(_)).WillByDefault(Return(Tails));

    controller.setEngine(mockGame);
    driver.pressPlayButton();
}

TEST_F(ControllerTest, doubleup_button_press_resets_doubleup_graphics)
{
    Controller controller(view());
    EXPECT_CALL(view(), resetDoubleUpScreenGraphics());
    ButtonDriver driver(controller);
    driver.pressDoubleUpButton();
}

TEST_F(ControllerTest, payout_button_press_resets_all_graphics)
{
    Controller controller(view());
    EXPECT_CALL(view(), resetGraphics());
    ButtonDriver driver(controller);
    driver.pressPayoutButton();
}

TEST_F(ControllerTest, double_prompt_after_win)
{
    Controller controller(view());
    RandCoinFlipLogic logic;
    AlwaysWinGame game(logic);
    controller.setEngine(game);

    EXPECT_CALL(view(), showDoubleUpScreen()).Times(1);



    ButtonDriver driver(controller);
    driver.pressPlayButton();

    ASSERT_EQ(WIN_AND_DOUBLE_QUERY, controller.getCurrentState());
}

TEST_F(ControllerTest, show_double_result_when_double_selected) {
    Controller controller(view());
    RandCoinFlipLogic logic;
    AlwaysWinGame game(logic);
    controller.setEngine(game);

    EXPECT_CALL(view(), showDoubleupResult(_)).Times(1);

    ButtonDriver driver(controller);
    driver.pressPlayButton();
    driver.pressDoubleUpButton();


}

