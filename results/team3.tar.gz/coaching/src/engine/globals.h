#ifndef GLOBALS_H
#define GLOBALS_H

enum Side {
    Tails = 0,
    Heads
};

enum GameResult {
	Lose = 0,
	Win,
	BigWin,
	InProgress,
	Idle
};

#endif // GLOBALS_H
