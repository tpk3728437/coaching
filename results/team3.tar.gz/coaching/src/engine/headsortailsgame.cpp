#include "headsortailsgame.h"
#include <time.h>
#include <stdlib.h>




HeadsOrTailsGame::HeadsOrTailsGame(RandomLogicInterface& flipper) : mFlipper(flipper), mListener(0), mCurrentState(Idle)
{

}

HeadsOrTailsGame::~HeadsOrTailsGame()
{
}

void HeadsOrTailsGame::play()
{
	while (gameCanBeWon())
	{
		mCoinFlips.push_back(mFlipper.flip());
	}
	mCurrentState = result();

	if (mListener)
		mListener->resultsComplete(mCoinFlips);
}

void HeadsOrTailsGame::doubleup()
{
	if (mCurrentState != Win) throw ExceptionIllegalDouble();
	if (mFlipper.flip() == Heads) {
		mCurrentState = Win;
	}
	else {
		mCurrentState = Lose;
	}
}

void HeadsOrTailsGame::reset()
{
	mCoinFlips.clear();
	// mCurrentState = Idle;
}

GameResult HeadsOrTailsGame::result()
{
	if (countSides(Heads) == 3)
		return BigWin;
	if (countSides(Heads) == 2)
		return Win;
	if (countSides(Tails) == 2)
		return Lose;
	return InProgress;
}

GameResult HeadsOrTailsGame::getState() {
	return mCurrentState;
}



bool HeadsOrTailsGame::gameCanBeWon()
{
	if (mCoinFlips.size() < 3)
	{
		if ((mCoinFlips.size() >= 2) && (mCoinFlips[0] == Tails && mCoinFlips[1] == Tails))
			return false;
		else
			return true;
	}
	return false;
}

int HeadsOrTailsGame::countSides(Side side)
{
	int rv = 0;
	std::vector<Side>::iterator it = mCoinFlips.begin();
	while (it != mCoinFlips.end())
	{
		if (*it == side)
			rv++;
		++it;
	}
	return rv;
}

void HeadsOrTailsGame::addListener(HeadsOrTailsListener* l)
{
	mListener = l;
}
