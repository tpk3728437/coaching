#ifndef _RANDOM_LOGIC_H_
#define _RANDOM_LOGIC_H_

#include <gmock/gmock.h>

class RandomLogicInterface
{
public:
	virtual Side flip() = 0;
};

class MockRandomCoinFlip : public RandomLogicInterface
{
public:
	MOCK_METHOD0(flip, Side());
};

#endif
