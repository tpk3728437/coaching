#ifndef HEADSORTAILS_H
#define HEADSORTAILS_H

#include "globals.h"
#include "RandomLogic.h"

#include <vector>

class GamePlay;
class Player;

class ExceptionIllegalDouble {};

class HeadsOrTailsListener
{
public:
	virtual void resultsComplete(std::vector<Side >) = 0;
};

class Game 
{
public:
    virtual void play() =0;
    virtual void doubleup() = 0;
    virtual void reset() = 0;
    virtual GameResult getState() = 0;
};

/**
 * This class is responsible for implementing the 
 * game logic.
 */ 
class HeadsOrTailsGame : public Game
{
public:
    HeadsOrTailsGame(RandomLogicInterface& flipper);
    virtual ~HeadsOrTailsGame();

public: // from game
    void play();
    void doubleup();
    void reset();
    GameResult getState();
    void addListener(HeadsOrTailsListener* l);
    
private: // data members

    bool gameCanBeWon();
    int countSides(Side side);

    GameResult result();

    RandomLogicInterface& mFlipper;
    std::vector<Side> mCoinFlips;
    HeadsOrTailsListener* mListener;
    GameResult mCurrentState;
};

#endif //HEADSORTAILS_H
