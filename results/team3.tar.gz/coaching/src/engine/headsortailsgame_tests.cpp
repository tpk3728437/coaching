#include <limits.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "headsortailsgame.h"
#include "globals.h"
#include "../viewinterface.h"
#include "RandomLogic.h"

using ::testing::_;
using ::testing::Return;
using ::testing::InSequence;
using ::testing::AllOf;
using ::testing::Ge;
using ::testing::Le;
using ::testing::Invoke;

//class MockView : public ViewInterface
//{
//public:
//    virtual ~MockView() {}
//    virtual void startRendering() {};
//    virtual void quit() {};
//    virtual void setInputInspector(InputInspector& inputInspector) {}
//    virtual void resetGraphics() {}
//    MOCK_METHOD0(showDoubleUpScreen, void());
//    MOCK_METHOD0(resetDoubleUpScreenGraphics, void());
//    virtual void showDoubleupResult(bool win) {}
//    virtual void showGameLoss() {}
//    virtual void showBigWin() {}
//    virtual void showBaseGameCoin(int index, Side side) {}
//    virtual void showDoubleUpCoin(Side side) {}
//
//    virtual ViewportSize getViewportSize() const {}
//    virtual std::string windowHandle() const {}
//};


class HeadsOrTailsGameTest : public ::testing::Test
{
public:
	HeadsOrTailsGameTest() : logic(), game(logic)
	{
	}

	MockRandomCoinFlip logic;
	HeadsOrTailsGame game;
};

TEST_F(HeadsOrTailsGameTest, lose_with_two_tails)
{
	EXPECT_CALL(logic, flip())
	    .WillOnce(Return(Tails))
	    .WillOnce(Return(Heads))
	    .WillRepeatedly(Return(Tails));

	game.play();
	ASSERT_EQ(Lose, game.getState());
}

TEST_F(HeadsOrTailsGameTest, win_with_two_heads)
{
	EXPECT_CALL(logic, flip())
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Tails))
	    .WillRepeatedly(Return(Heads));

	game.play();
	ASSERT_EQ(Win, game.getState());
}

TEST_F(HeadsOrTailsGameTest, win_big_with_three_heads)
{
	EXPECT_CALL(logic, flip())
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Heads));

	game.play();
	ASSERT_EQ(BigWin, game.getState());
}

TEST_F(HeadsOrTailsGameTest, if_two_tails_do_not_flip_third)
{
	EXPECT_CALL(logic, flip())
	    .Times(::testing::Exactly(2))
	    .WillOnce(Return(Tails))
	    .WillOnce(Return(Tails));

	game.play();
}

TEST_F(HeadsOrTailsGameTest, throw_when_illegal_double)
{
	EXPECT_CALL(logic, flip())
	    .WillOnce(Return(Tails))
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Tails));

	game.play();
	ASSERT_THROW(game.doubleup(), ExceptionIllegalDouble);
}

TEST_F(HeadsOrTailsGameTest, allow_double_when_win)
{
	EXPECT_CALL(logic, flip())
	    .WillOnce(Return(Tails))
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Heads))
	    .WillRepeatedly(Return(Heads));

	game.play();
	ASSERT_NO_THROW(game.doubleup());
}

TEST_F(HeadsOrTailsGameTest, doubling_logic_works)
{
	EXPECT_CALL(logic, flip())
	    .WillOnce(Return(Tails))
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Heads))
	    .WillOnce(Return(Tails));

	game.play();

	game.doubleup();

	ASSERT_EQ(Win, game.getState());

	game.doubleup();

	ASSERT_EQ(Lose, game.getState());
}

