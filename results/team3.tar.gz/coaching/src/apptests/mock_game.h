#ifndef MOCK_GAME_H
#define MOCK_GAME_H

#include <gmock/gmock.h>
#include "headsortailsgame.h"
#include "globals.h"


class MockGame : public Game
{
public:
    MOCK_METHOD0(play, void());
    MOCK_METHOD0(doubleup, void());
    MOCK_METHOD0(reset, void());
    MOCK_METHOD0(getState, GameResult());
};

#endif // MOCK_GAME_H
