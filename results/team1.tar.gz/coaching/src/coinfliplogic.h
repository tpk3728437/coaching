#ifndef COINFLIPLOGIC_H
#define COINFLIPLOGIC_H

#include "engine/globals.h"


class CoinFlipLogic {
public:
	virtual ~CoinFlipLogic() {}

	virtual Side flip() = 0;

private:
};

/**
 * This class is responsible for implementing the coin flipping
 * algorithm. Each call to the flip function will flip the coin
 * and return the result.
 */
class RandCoinFlipLogic : public CoinFlipLogic
{
public:
	RandCoinFlipLogic();
    ~RandCoinFlipLogic();

    Side flip();
    
private:

};


#endif // COINFLIPLOGIC_H

