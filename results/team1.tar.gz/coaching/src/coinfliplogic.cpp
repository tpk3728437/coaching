#include "coinfliplogic.h"
#include <stdlib.h>
#include <time.h>

RandCoinFlipLogic::RandCoinFlipLogic()
{
    srand(time(NULL));
}

RandCoinFlipLogic::~RandCoinFlipLogic()
{
}

Side RandCoinFlipLogic::flip()
{
    // random
    Side side = (Side) (rand() % 2);
    return side;
}
