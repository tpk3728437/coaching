#include "headsortailsgame.h"
#include <time.h>
#include <stdlib.h>
#include <iostream>

HeadsOrTailsGame::HeadsOrTailsGame(CoinFlipLogic& logic) :
		mCoinFlipLogic(logic) {
}

HeadsOrTailsGame::~HeadsOrTailsGame() {
}

void HeadsOrTailsGame::play(GameMode mode) {
	mGameMode = mode;
	mFlips.clear();
	switch (mGameMode) {
	case DEFAULT: {

		mFlips.push_back(mCoinFlipLogic.flip());
		mFlips.push_back(mCoinFlipLogic.flip());
		mFlips.push_back(mCoinFlipLogic.flip());
		break;
	}
	case DOUBLE: {
		mFlips.push_back(mCoinFlipLogic.flip());
		break;
	}
	}
}

GameResult HeadsOrTailsGame::checkResult() {
	int tailsCount = 0;
	int headsCount = 0;
	switch (mGameMode) {
	case DEFAULT: {
		for (int i = 0; i < mFlips.size(); ++i) {
			if (mFlips[i] == TAILS)
				tailsCount++;
			if (mFlips[i] == HEADS)
				headsCount++;

			if (tailsCount == 2) {
				if (i == 1)
					return LOSE_TWO_COINS;
				else
					return LOSE_THREE_COINS;
			}
		}

		if (headsCount == 3)
			return WINBIG;
		else if (headsCount == 2)
			return WIN;
	}
	case DOUBLE: {
		if (mFlips[0] == HEADS)
			return WIN_DOUBLE;
		else return LOSE_DOUBLE;
	}
	}
}

