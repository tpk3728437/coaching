#include <limits.h>
#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "headsortailsgame.h"

#include "../coinfliplogic.h"

using ::testing::_;
using ::testing::Return;
using ::testing::InSequence;
using ::testing::AllOf;
using ::testing::Ge;
using ::testing::Le;
using ::testing::Invoke;



class StubCoinFlipLogicCustom : public CoinFlipLogic
{
public:
	StubCoinFlipLogicCustom() :index(0)  {
	}

	void setSides(Side s1,Side s2, Side s3) {
		 sides[0] = s1;
		 sides[1] = s2;
		 sides[2] = s3;
	}

	Side flip() {
		return sides[index++];
	}

	Side reset(){
		index = 0;
	}


private:
	int index;
	Side sides[3];

};



class HeadsOrTailsGameTest : public ::testing::Test
{
public:
//	HeadsOrTailsGameTest() {game.play()};
//	HeadsOrTailsGame game;
public:
	void SetUp() {
	}
	StubCoinFlipLogicCustom logic;
};

TEST_F(HeadsOrTailsGameTest, lose_with_two_tails)
{
	logic.setSides(TAILS,TAILS,HEADS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(LOSE_TWO_COINS,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest, win_with_two_heads)
{
	logic.setSides(TAILS,HEADS,HEADS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(WIN,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest, loses_with_three_coins)
{
	logic.setSides(TAILS,HEADS,TAILS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(LOSE_THREE_COINS,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest, jackpot)
{
	logic.setSides(HEADS,HEADS,HEADS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(WINBIG,game.checkResult());

}

TEST_F(HeadsOrTailsGameTest, skip_third_coin_with_two_tails) {
	logic.setSides(TAILS,TAILS,HEADS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(LOSE_TWO_COINS,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest , double_possible_when_two_heads){
	logic.setSides(HEADS,HEADS,TAILS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(WIN,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest , double_win_when_heads){
	logic.setSides(HEADS,HEADS,TAILS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(WIN,game.checkResult());

	logic.reset();
	logic.setSides(HEADS,NONE,NONE);
	game.play(DOUBLE);
	ASSERT_EQ(WIN_DOUBLE,game.checkResult());
}

TEST_F(HeadsOrTailsGameTest , double_lose_when_tails){
	logic.setSides(HEADS,HEADS,TAILS);
	HeadsOrTailsGame game(logic);
	game.play();
	ASSERT_EQ(WIN,game.checkResult());

	logic.reset();
	logic.setSides(TAILS,NONE,NONE);
	game.play(DOUBLE);
	ASSERT_EQ(LOSE_DOUBLE,game.checkResult());
}

