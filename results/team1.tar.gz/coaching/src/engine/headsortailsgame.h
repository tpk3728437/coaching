#ifndef HEADSORTAILS_H
#define HEADSORTAILS_H


#include "../coinfliplogic.h"


#include "globals.h"
#include <vector>

class GamePlay;
class Player;

enum GameResult {
	WIN = 0,
	WIN_DOUBLE,
	LOSE_DOUBLE,
	LOSE_TWO_COINS,
	LOSE_THREE_COINS,
	WINBIG
};

enum GameMode {
	DEFAULT = 0,
	DOUBLE
};

class Game 
{
public:
    virtual void play(GameMode mode = DEFAULT) = 0;
    virtual Side getSide(int index) = 0;
    virtual GameResult checkResult() = 0;
};

/**
 * This class is responsible for implementing the 
 * game logic.
 */ 
class HeadsOrTailsGame : public Game
{
public:
    HeadsOrTailsGame(CoinFlipLogic& logic);
    virtual ~HeadsOrTailsGame();

public: // from game
    void play(GameMode mode = DEFAULT);
    
    GameResult checkResult();

    Side getSide(int index) {
    	return mFlips[index];
    }

private: // data members
    CoinFlipLogic&           mCoinFlipLogic;
    std::vector<Side> mFlips;
    GameMode mGameMode;

};

#endif //HEADSORTAILS_H
