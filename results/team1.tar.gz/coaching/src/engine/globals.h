#ifndef GLOBALS_H
#define GLOBALS_H

enum Side {
    TAILS = 0,
    HEADS,
    NONE
};

#endif // GLOBALS_H
