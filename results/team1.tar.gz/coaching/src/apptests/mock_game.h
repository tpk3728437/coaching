#ifndef MOCK_GAME_H
#define MOCK_GAME_H

#include <gmock/gmock.h>
#include "headsortailsgame.h"


class MockGame : public Game
{
public:
    MOCK_METHOD1(play, void(GameMode));
    MOCK_METHOD1(getSide, Side(int));
    MOCK_METHOD0(checkResult, GameResult());
};

#endif // MOCK_GAME_H
